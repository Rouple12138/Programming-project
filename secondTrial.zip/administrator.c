#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"book_management.h"
#define N 50

void administrator_login() //For administrator to log in
{
	char name[N];
	char password[N];
	User* account;
	printf("PLease enter your account: \n");
	scanf("%s", name);
	if(account = find_useraccount(name), account == NULL)
	{
		printf("The account does not exist, please enter it again!\n");
		return;
	}
	if(!account->administrator)
	{
		printf("This account has no administrative authority!\n");
		return;
	}
	printf("Please enter your password: \n");
	scanf("%s", password);
	if(strcmp(account ->password, password))
	{
		printf("Wrong password, please confirm and log in again!\n");
		return;
	}
	printf("Log in successfully!\n");
	menu_administrator(account);
}

void menu_administrator()//The interface displayed after the administrator logs in
{
	while(1)
	{
		int option;
		printf("Please choose an option:\n");
		printf("1) Add a book\n");
		printf("2) Remove a book\n");
		printf("3) Search for books\n");
		printf("4) Display all books\n");
		printf("5) Log out\n");
		scanf("%d",&option);
		switch(option)
		{
		case 1: add_a_book();
		break;
		case 2: remove_a_book();
		break;
		case 3: find_book();
		break;
		case 4: displayBooks();
		break;
		case 5: printf("Logging out...\n");
		return;
		default:
			printf("Invalid option, please re-enter!\n");
			break;
		}
	}
}

User* find_useraccount(char* account)//Find a specific user
 {
	 User* p1 = user_head->next;
	 while(p1)
	 {
	     printf("p1->user_account is %s\n", p1->user_account);
	     printf("account is %s\n", account);
		 if(!strcmp(p1->user_account, account))
		 {
			 return p1;
		 }
		 p1 = p1->next;
	 }
	 return NULL;
 }

void load()  //Load data from file
{
	book_head = (Book*)malloc(sizeof(Book));
	book_head->next = NULL;
	book_amount = 0;

	FILE* fp2;
	fp2 = fopen("book.bin", "rb");
	if (fp2 == NULL)
	{
		fp2 = fopen("book.bin", "wb");
		if (fp2 == NULL)
		{
			printf("Load failed！\n"); exit(0);
		}
		fclose(fp2);
	}
	else
	{
		Book* p1;
		p1 = book_head;
		Book* p2 = (Book*)malloc(sizeof(Book));
		int count = 0; //To count how many books save
		int length = 0;//To count how long the title and authors are
		char temp[N];
        fread(&count, sizeof(int), 1, fp2);
        for(int i = 0; i < count; i++)
        {
            p1->next = p2;
            ++book_amount;
            fread(&p2->id, sizeof(int), 1, fp2);
            fread(&length, sizeof(int), 1, fp2);
            printf("length : %d\n", length);
            p2->title = (char*)malloc(sizeof(char) * length);
            fread(p2->title, sizeof(char) * length,1, fp2);
           // p2->title = temp;
            printf("p2->title :%s\n", p2->title);
            fread(&length, sizeof(int), 1, fp2);
            printf("length :%d\n", length);
            p2->authors = (char*)malloc(sizeof(char) * length);
            fread(p2->authors, sizeof(char) * length,1, fp2);
            //p2->authors = temp;
            printf("p2->authors :%s\n", p2->authors);
            fread(&p2->year, sizeof(int), 1, fp2);
            fread(&p2->copies, sizeof(int), 1, fp2);
            p2 = p2->next;
            p2 = (Book*)malloc(sizeof(Book));
            p1 = p1->next;
        }
        fclose(fp2);
		/*while (fread(p2, sizeof(Book), 1, fp2))
		{
			p1->next = p2;
			++book_amount;
			p2 = p2->next;
			p2 = (Book*)malloc(sizeof(Book));
			p1 = p1->next;
		}
		fclose(fp2);*/
	}

	user_head = (User*)malloc(sizeof(User));
	user_head->next = NULL;
	user_amount = 0;

	FILE* fp1;
	fp1 = fopen("user.bin", "rb");
	if (fp1 == NULL)
		{
			return;
		}
	User* p3 ;
	p3 = user_head;
	User* temp = (User*)malloc(sizeof(User));
	while (fread(temp, sizeof(User), 1, fp1))
	{
		p3->next = temp;
		++user_amount;
		//temp = temp->next;
		temp = (User*)malloc(sizeof(User));
		p3 = p3->next;
	}
	testAccount = user_head->next;
	fclose(fp1);
}

void save()  //Save data to file
{
	FILE* p1 = fopen("user.bin", "wb");
	User* temp = user_head->next;
	while (temp)
	{
		fwrite(temp, sizeof(User), 1, p1);
		temp = temp->next;
	}
	fclose(p1);

	p1 = fopen("book.bin", "wb");
	Book* p2 = book_head->next;
    int count = 0;
	while(p2)
    {
	    count++;
	    p2 = p2->next;
    }
	p2 = book_head->next;
    fwrite(&count, sizeof(int), 1, p1);
	while (p2)
	{
	    char temp1[N];
	    fwrite(&p2->id, sizeof(int), 1, p1);
	    int length = strlen(p2->title) + 1;
        fwrite(&length, sizeof(int), 1, p1);
	    strcpy(temp1, p2->title);
        fwrite(temp1, sizeof(char) * length, 1, p1);
        length = strlen(p2->authors) + 1;
        fwrite(&length, sizeof(int), 1, p1);
        strcpy(temp1, p2->authors);
        fwrite(temp1, sizeof(char) * length, 1, p1);
        fwrite(&p2->year, sizeof(int), 1, p1);
        fwrite(&p2->copies, sizeof(int), 1, p1);
		p2 = p2->next;
	}
	fclose(p1);
}
