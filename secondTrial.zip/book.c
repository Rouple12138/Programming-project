#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"book_management.h"
#define N 50



void borrow_book(User* account)//For user to borrow book
{
	//while(1)
	//{
    FILE* p1 = fopen("user.bin", "wb");

	int nowAmount = account->user_book.borrow_amount;
		displayBooks();
		int number;
		int id;
		printf("Enter the ID number of book you wish to borrow: \n");
		scanf("%d", &id);
		getchar();
		if (id > book_amount ||id <= 0)
		{
			printf("Please correctly input the existing book number!\n");
		}
		else
		{
			Book* p1;
			p1 = book_head->next;
			for(int i = 1;i < id; ++i)
				{
					p1 = p1->next;
				}
			account->user_book.borrow_book[nowAmount].id = p1->id;
			account->user_book.borrow_book[nowAmount].title = p1->title;
			++account->user_book.borrow_amount;
			p1->copies = p1->copies - 1;
			printf("account->user_book.borrow_book[nowAmount].id : %d\n", account->user_book.borrow_book[nowAmount].id);
			printf("account->user_book.borrow_book[nowAmount].title: %s\n", account->user_book.borrow_book[nowAmount].title);
			printf("account->user_book.borrow_book[nowAmount].author : %s\n", account->user_book.borrow_book[nowAmount].authors);
			printf("account->user_book.borrow_book[nowAmount].year : %d\n", account->user_book.borrow_book[nowAmount].year);
			printf("account->user_book.borrow_book[nowAmount].copies : %d\n", account->user_book.borrow_book[nowAmount].copies);
			save();
			printf("You have successfully borrowed the book!\n");
		}
	//}
}

void return_book(User* account)//For user to return book
{
	displayHistory(account);
	//while(1)
	//{
		printf("Enter the ID number of the book you wish to return: \n");
		int id = 0;
		scanf("%d", &id);
		if(id > book_amount || id < 0)
		{
			printf("Please correctly enter the book id!\n");
		}
		else
		{
			int i = 0;
			for(--id; i < id; ++i);
			char title[N];
			strcpy(title,account->user_book.borrow_book[i].title);
			for(;i < account->user_book.borrow_amount; ++i)
			{
				account->user_book.borrow_book[i] = account->user_book.borrow_book[i+1];
			}
			--account->user_book.borrow_amount;
			save();
			printf("Returned book successfully!\n");
		}
	//}
}

void create_list_book(int id, char* title, char* authors, int year, int copies)//Create a linked list of books
{
	Book* p1;
	p1 = book_head;
	while (p1->next)
    {p1 = p1->next;}
	Book* p2 = (Book*)malloc(sizeof(Book));
	int size = strlen(title) + 1;
    p2->title = (char*)malloc(sizeof(char) * size);
    size = strlen(authors) + 1;
    p2->authors = (char*)malloc(sizeof(char) * size);
	strcpy(p2->title, title);
	strcpy(p2->authors, authors);
	p2->id = id;
	p2->year = year;
	p2->copies = copies;
	p2->next = NULL;
	p1->next = p2;
	save();
}

void displayBooks()//Display all the books
{
	if(!book_amount)
	{
		printf("No books!\n");
		return;
	}
	Book* p1 ;
	p1 = book_head->next;
	printf("ID\tTitle\t\tAuthors\t\tYear\tCopies\t\n");
	while(p1)
	{
		printf("%d\t%s\t\t%s\t\t%d\t%d\t\n", p1->id, p1->title, p1->authors, p1->year, p1->copies);
		p1 = p1->next;
	}
}

void add_a_book()//For administrator add a book
{
	char title[N], authors[N];
	int id, year, copies;
	printf("Please enter the ID\n");
	scanf("%d", &id);
	getchar();
	printf("Please enter the title\n");
	scanf("%s", title);
    getchar();
	printf("Please enter the authors\n");
	scanf("%s", authors);
    getchar();
	printf("Please enter the year\n");
	scanf("%d", &year);
    getchar();
	printf("Please enter the copies\n");
	scanf("%d", &copies);
    getchar();
	++book_amount;
	create_list_book(id, title, authors, year, copies);
	printf("Successfully add!\n");
}
void remove_a_book()//For administrator remove a book
{
	int id = 0;
	//while(1)
	//{
		displayBooks();
		printf("Please enter the ID number of book you want to remove\n ");
		scanf("%d", &id);
		if (id > book_amount ||id <= 0)
		{
			printf("Please correctly input the existing book number!\n");
		}
		else
		{
			Book* p1 = (Book*)malloc(sizeof(Book));
			Book* p2 = (Book*)malloc(sizeof(Book));
			p2 = book_head;
			p1 = book_head->next;
			for (int i = 1; i < id; ++i)
				{
					p2 = p1;
					p1 = p1->next;
				}
			p2->next = p1->next;
			free(p2);
			--book_amount;
			save();
			printf("Successfully remove!\n");
		}
	//}
}

void find_book()
{
    printf("find a book");
}

