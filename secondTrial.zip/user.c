
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"book_management.h"
#define N 50


void create_list_user(char* account, char* password)//Create a linked list of users
{
	User* p1 ;
	p1 = user_head;
	while(p1->next)
	{
		p1 = p1->next;
	}
	User* p2 = (User*)malloc(sizeof(User));
	strcpy(p2->user_account,account);
	strcpy(p2->password,password);
	p2->administrator = 0;
	p2->next = NULL;
	p1->next = p2;
	save();
}


void user_register()//Register a new user
{
	char name[N];
	char password[N];
	printf("\nPlease enter a username:\n");
	scanf("%s",name);
	User* account;
	if(account = find_useraccount(name), account != NULL)
	{
		printf("Sorry, registration unsuccessful, the username you entered already exists.");
		return;
	}
    printf("\nPlease enter a password:\n");
	scanf("%s",password);
	create_list_user(name, password);
	printf("Registered library account successfully!\n");
	user_amount = ++user_amount;
}

void user_login()
{
	char name[N];
	char password[N];
	User* account;
	printf("\nPlease enter a username:\n");
	scanf("%s",name);
	if(account = find_useraccount(name), account == NULL)
	{
		printf("The user name does not exist, please register or re-login account!\n");
		return;
	}
	printf("\nPlease enter a password:\n");
	scanf("%s",password);
	if (strcmp(account->password, password))
	{
		printf("Wrong password, please confirm and log in again!\n");
		return;
	}
	printf("Log in successfully!\n");
	menu_user(account);
}

void menu_user(User* account)//The interface displayed after the user logs in
{
	while(1)
	{
		int option;
		printf("Please choose an option:\n");
		printf("1) Borrow a book\n");
		printf("2) Return a book\n");
		printf("3) Search for books\n");
		printf("4) Display all books\n");
		printf("5) Log out\n");
		scanf("%d", &option);
		switch(option)
		{
		case 1: borrow_book(account);
		break;
		case 2: return_book(account);
		break;
		case 3: find_book();
		break;
		case 4: displayBooks();
		break;
		case 5: printf("Logging out...\n");
		return;
		default:
			printf("Invalid option, please re-enter!\n");
			break;
		}
	}
}

void displayHistory(User* account)//Display the history that user borrowed books
{
	int n = account->user_book.borrow_amount;
	printf("User %s \n", account->user_account);
	if(!n)
	{
		printf("There is no record of borrowing books!\n");
	}
	for(int i = 0; i < n; ++i)
	{
		struct node t = account->user_book;
        printf("  ID: %d\n",t.borrow_book[i].id);
		printf("  Title: %s\n", t.borrow_book[i].title);
		printf("  Author: %s\n", t.borrow_book[i].authors);
		printf("  Year: %d\n", t.borrow_book[i].year);
	}
}
