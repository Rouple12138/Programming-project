#include <stdio.h>
#include "book_management.h"
#define N 50


int main ()
{
	int k;
	load();
	while(1)
	{
		printf("\nPlease choose an option:\n");
		printf("1) Register an account\n");
		printf("2) Login as user\n");
		printf("3) Login as administrator\n");
		printf("4) Search for books\n");
		printf("5) Display all books\n");
		printf("6) Quit\n");
		printf(" Option:\n");
		scanf("%d", &k);
		getchar();
		switch(k)
		{
		case 1: user_register();
		break;
		case 2: user_login();
		break;
		case 3: administrator_login();
		break;
		case 4: find_book();
		break;
		case 5: displayBooks();
		break;
		case 6: return 1;
		default:
			printf("Wrong option, please enter again!\n");
		}
	}
}
