#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"book_management.h"
#define N 50



void borrow_book(User* account)//For user to borrow book
{
	int nowAmount = account->user_book.borrow_amount;
	displayBooks();
	int id;
	printf("Enter the ID number of book you wish to borrow: \n(Or you can choose enter 0 to back the menu)");
	scanf("%d", &id);
	getchar();
	if (id > book_amount ||id <= 0)
	{
	    printf("Please correctly input the existing book number!\n");
	}
	else{
	    Book* p1;
	    p1 = book_head->next;
	    for(int i = 1;i < id; ++i)
	    {
	        p1 = p1->next;
	    }
	    account->user_book.borrow_book[nowAmount] = *p1;
	    //account->user_book.borrow_book[nowAmount].title = p1->title;
	    ++account->user_book.borrow_amount;
	    p1->copies = p1->copies - 1;
	    save();
	    printf("You have successfully borrowed the book!\n");
		}
}

void return_book(User* account)//For user to return book
{
	displayHistory(account);
	printf("Enter the ID number of the book you wish to return: \n(Or you can choose enter 0 to back the menu)");
	int id = 0;
	scanf("%d", &id);
	getchar();
	if(id > book_amount || id < 0)
	{
	    printf("Please correctly enter the book id!\n");
	}
	else{
        Book* p1 = find_abook_by_id(id);
	    int i = 0;
	    for(--id; i < id; ++i);
	    char title[N];
	    strcpy(title,account->user_book.borrow_book[i].title);
	    for(;i < account->user_book.borrow_amount; ++i)
	    {
	        account->user_book.borrow_book[i] = account->user_book.borrow_book[i+1];
	    }
	    --account->user_book.borrow_amount;
	    p1->copies  = p1->copies + 1;
	    save();
	    printf("Returned book successfully!\n");
		}
}

void create_list_book(int id, char* title, char* authors, int year, int copies)//Create a linked list of books
{
	Book* p1;
	p1 = book_head;
	while (p1->next)
    {
	    p1 = p1->next;
    }
	Book* p2 = (Book*)malloc(sizeof(Book));
	/*int size = strlen(title) + 1;
    p2->title = (char*)malloc(sizeof(char) * size);
    size = strlen(authors) + 1;
    p2->authors = (char*)malloc(sizeof(char) * size);*/
	strcpy(p2->title, title);
	strcpy(p2->authors, authors);
	p2->id = id;
	p2->year = year;
	p2->copies = copies;
	p2->next = NULL;
	p1->next = p2;
	save();
}

void displayBooks()//Display all the books
{
	if(!book_amount)
	{
		printf("No books!\n");
		return;
	}
	Book* p1 ;
	p1 = book_head->next;
	printf("ID\tTitle\t\tAuthors\t\tYear\tCopies\t\n");
	while(p1)
	{
		printf("%d\t%s\t\t%s\t\t%d\t%d\t\n", p1->id, p1->title, p1->authors, p1->year, p1->copies);
		p1 = p1->next;
	}
}

void add_a_book()//For administrator add a book
{
	char title[N], authors[N];
	int id, year, copies;
	printf("Please enter the ID\n");
	scanf("%d", &id);
	getchar();
	printf("Please enter the title\n");
	scanf("%s", title);
    getchar();
	printf("Please enter the authors\n");
	scanf("%s", authors);
    getchar();
	printf("Please enter the year\n");
	scanf("%d", &year);
    getchar();
	printf("Please enter the copies\n");
	scanf("%d", &copies);
    getchar();
	++book_amount;
	create_list_book(id, title, authors, year, copies);
	printf("Successfully add!\n");
}
void remove_books()//For administrator remove a book
{
	int id = 0;
	displayBooks();
	printf("Please enter the ID number of book you want to remove\n ");
	scanf("%d", &id);
	getchar();
	if (id > book_amount ||id <= 0)
	{
	    printf("Please correctly input the existing book number!\n");
	}
	else{
	    Book* p1;
	    Book* p2;
	    p2 = book_head;
	    p1 = book_head->next;
	    for (int i = 1; i < id; ++i)
	    {
	        p2 = p1;
	        p1 = p1->next;
	    }
	    p2->next = p1->next;
	    free(p2);
	    --book_amount;
	    save();
	    printf("Successfully remove!\n");
		}
}

void find_book()
{
    Book* p1;
    printf("Which way do you want to find a book?\n");
    printf("1) By title.\n");
    printf("2) By authors.\n");
    printf("3) By year.\n");
    int option;
    scanf("%d", &option);
    getchar();
    char temp[N];
    int year;
    switch (option)
    {
        case 1:
        {
            printf("Please enter the title.\n");
            scanf("%s", temp);
            if (NULL == find_abook_by_title(temp)) {
                printf("No result!\n");
                break;
            } else {
                p1 = find_abook_by_title(temp);
                printf("Find successfully!\n");
                printf("There are %d books rest.\n", p1->id);
                break;
            }
        }
        case 2:
        {
            printf("Please enter the authors.\n");
            scanf("%s", temp);
            if (NULL == find_abook_by_authors(temp)) {
                printf("No result!\n");
                break;
            } else {
                p1 = find_abook_by_authors(temp);
                printf("Find successfully!\n");
                printf("There are %d books rest.\n", p1->id);
                break;
            }
        }
        case 3:
        {
            printf("Please enter the year\n");
            scanf("%d", &year);
            if (NULL == find_abook_by_year(year)) {
                printf("No result!\n");
                break;
            } else {
                p1 = find_abook_by_year(year);
                printf("Find successfully!\n");
                printf("There are %d books rest.\n", p1->id);
                break;
            }
        }
        default:
            printf("Wrong option, please enter again!\n");
    }
}

Book* find_abook_by_title(char* title)
{
    Book* p1 = book_head->next;
    while(p1)
    {
        for(int i = -1; ++i < N; )
        {
            if(p1->title[i] != title[i])
            {
                p1 = p1->next;
                break;
            }
            return p1;
        }
    }
    return NULL;
}

Book* find_abook_by_authors(char* authors)
{
    Book* p1 = book_head->next;
    while(p1)
    {
        for(int i = -1; ++i < N; )
        {
            if(p1->authors[i] != authors[i])
            {
                p1 = p1->next;
                break;
            }
            return p1;
        }
    }
    return NULL;
}

Book* find_abook_by_year(int year)
{
    Book* p1 = book_head->next;
    while(p1)
    {
        if(p1->year == year)
        {
            return p1;
        }
        p1 = p1->next;
    }
    return NULL;
}


Book* find_abook_by_id(int id)
{
    Book* p1 = book_head->next;
    while(p1)
    {
        if(p1->id == id)
        {
            return p1;
        }
        p1 = p1->next;
    }
    return NULL;
}